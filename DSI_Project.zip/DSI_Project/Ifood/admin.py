from django.contrib import admin
from .models import consumidor, Endereco

# Register your models here.

admin.site.register(consumidor)
admin.site.register(Endereco)